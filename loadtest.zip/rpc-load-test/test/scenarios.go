package test

import (
	"math/big"
	"math/rand"
	"time"

	"rpc-load-test/utils"
	"rpc-load-test/utils/logutil"

	"github.com/ethereum/go-ethereum/common"
)

func Run_RPC_eth_call_getAmountsOut(cfg *utils.Config, method string) []*utils.Response {
	//
	r := rand.Intn(int(cfg.Range))
	height := cfg.Height - int64(r)
	r = rand.Intn(len(cfg.Bep20Addrs))
	path := []common.Address{cfg.WBNBAddr, cfg.Bep20Addrs[r]}
	res, err := RPC_eth_call_getAmountsOut(cfg, method, height, path, 10)
	if err != nil {
		logutil.Errorf("%s-getAmountsOut: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

// TODO: add balanceOf eth_call test

func Run_RPC_eth_getStorageAt(cfg *utils.Config, method string) []*utils.Response {
	//
	r := rand.Intn(int(cfg.Range))
	height := cfg.Height - int64(r)
	r = rand.Intn(len(cfg.BEP20))
	bep20 := cfg.BEP20[r]
	res, err := RPC_eth_getStorageAt(cfg, method, height, bep20, 10)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_eth_getBalance(cfg *utils.Config, method string) []*utils.Response {
	r := rand.Intn(int(cfg.Range))
	height := cfg.Height - int64(r)
	r = rand.Intn(len(cfg.AccountList))
	bep20 := utils.T_cfg.BEP20[r]
	extAcc := cfg.AccountList[bep20][rand.Intn(len(cfg.AccountList[bep20]))]
	res, err := RPC_eth_getBalance(cfg, method, height, extAcc, 10)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_eth_getTransactionCount(cfg *utils.Config, method string) []*utils.Response {
	r := rand.Intn(int(cfg.Range))
	height := cfg.Height - int64(r)
	r = rand.Intn(len(cfg.AccountList))
	bep20 := utils.T_cfg.BEP20[r]
	extAcc := cfg.AccountList[bep20][rand.Intn(len(cfg.AccountList[bep20]))]
	res, err := RPC_eth_getTransactionCount(cfg, method, height, extAcc, 10)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_eth_getCode(cfg *utils.Config, method string) []*utils.Response {
	r := rand.Intn(int(cfg.Range))
	height := cfg.Height - int64(r)
	r = rand.Intn(len(cfg.BEP20))
	bep20 := cfg.BEP20[r]
	res, err := RPC_eth_getCode(cfg, method, height, bep20, 10)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_eth_getProof(cfg *utils.Config, method string) []*utils.Response {
	r := rand.Intn(int(cfg.Range))
	height := cfg.Height - int64(r)
	r = rand.Intn(len(cfg.BEP20))
	bep20 := cfg.BEP20[r]
	res, err := RPC_eth_getProof(cfg, method, height, bep20, []string{cfg.BEP20StorageAt}, 10)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_eth_estimateGas(cfg *utils.Config, method string) []*utils.Response {
	//
	r := rand.Intn(int(cfg.Range))
	height := cfg.Height - int64(r)
	r = rand.Intn(len(cfg.Bep20Addrs))
	addr := cfg.Bep20Addrs[r]
	res, err := RPC_eth_estimateGas(cfg, method, height, addr, cfg.RouterAddr, 10)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_debug_traceBlockByNumber(cfg *utils.Config, method string) []*utils.Response {
	//
	r := rand.Intn(int(cfg.Range))
	height := cfg.Height - int64(r)
	res, err := RPC_debug_traceBlockByNumber(cfg, method, height, 300)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_debug_traceTransaction(cfg *utils.Config, method string) []*utils.Response {
	//
	r := rand.Intn(len(cfg.TXHashList))
	txhash := common.HexToHash(cfg.TXHashList[r])
	res, err := RPC_debug_traceTransaction(cfg, method, txhash, 300)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_debug_traceCall(cfg *utils.Config, method string) []*utils.Response {
	//
	r := rand.Intn(int(cfg.Range))
	height := cfg.Height - int64(r)
	r = rand.Intn(len(cfg.Bep20Addrs))
	bep20Addr := cfg.Bep20Addrs[r]
	r = rand.Intn(len(cfg.AccountList))

	bep20 := utils.T_cfg.BEP20[r]
	extAcc := cfg.AccountList[bep20][rand.Intn(len(cfg.AccountList[bep20]))]
	extAccAddr := common.HexToAddress(extAcc)
	res, err := RPC_debug_traceCall(cfg, method, height, bep20Addr, extAccAddr, 300)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

// Run_RPC_eth_getLogs use block range and contractAddress for test
func Run_RPC_eth_getLogs(cfg *utils.Config, method string) []*utils.Response {
	blockRange := rand.Intn(int(cfg.Range))
	r := rand.Intn(len(cfg.Bep20Addrs) - 1)
	res, err := RPC_eth_getLogs(cfg, method, big.NewInt(cfg.Height-int64(blockRange)), big.NewInt(cfg.Height), cfg.Bep20Addrs[r:r+1], nil, nil, nil, nil, 300)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_net_version(cfg *utils.Config, method string) []*utils.Response {
	res, err := RPC_net_version(cfg, method, 300)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_eth_blockNumber(cfg *utils.Config, method string) []*utils.Response {
	res, err := RPC_eth_blockNumber(cfg, method, 300)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_eth_getTransactionReceipt(cfg *utils.Config, method string) []*utils.Response {
	r := rand.Intn(len(cfg.TXHashList))
	txhash := common.HexToHash(cfg.TXHashList[r])
	res, err := RPC_eth_getTransactionReceipt(cfg, method, txhash, 300)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_eth_getBlockByNumber(cfg *utils.Config, method string) []*utils.Response {
	r := rand.Intn(int(cfg.Range))
	height := cfg.Height - int64(r)
	res, err := RPC_eth_getBlockByNumber(cfg, method, height, 300)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_eth_chainId(cfg *utils.Config, method string) []*utils.Response {
	res, err := RPC_eth_chainId(cfg, method, 300)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}

func Run_RPC_eth_getTransactionByHash(cfg *utils.Config, method string) []*utils.Response {
	r := rand.Intn(len(cfg.TXHashList))
	txhash := common.HexToHash(cfg.TXHashList[r])
	res, err := RPC_eth_getTransactionByHash(cfg, method, txhash, 300)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
		res = &utils.Response{method, -1, nil, "", 0}
	}
	return []*utils.Response{res}
}
func Run_Websocket_eth_subscribe_newHeads(cfg *utils.Config, method string) []*utils.Response {

	dur := utils.T_cfg.StartTime.Add(time.Duration(cfg.DurationSec-1) * time.Second)

	res, err := Websocket_eth_subscribe_newHeads(cfg, method, dur)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
	}
	return res
}

func Run_Websocket_eth_subscribe_newPendingTransactions(cfg *utils.Config, method string) []*utils.Response {

	dur := utils.T_cfg.StartTime.Add(time.Duration(cfg.DurationSec-1) * time.Second)
	res, err := Websocket_eth_subscribe_newPendingTransactions(cfg, method, dur)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
	}
	return res
}

func Run_Websocket_eth_subscribe_logs(cfg *utils.Config, method string) []*utils.Response {
	//r := rand.Intn(len(cfg.Bep20Addrs) - 2)
	dur := utils.T_cfg.StartTime.Add(time.Duration(cfg.DurationSec-1) * time.Second)
	res, err := Websocket_eth_subscribe_logs(cfg, method, nil, nil, nil, nil, nil, dur)
	if err != nil {
		logutil.Errorf("%s: %s", method, err.Error())
	}
	return res
}
