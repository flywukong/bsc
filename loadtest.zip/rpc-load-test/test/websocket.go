package test

import (
	"math/rand"
	"time"

	"rpc-load-test/utils"
	"rpc-load-test/utils/logutil"

	"github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/common"

	"github.com/gorilla/websocket"
)

// Websocket_eth_subscribe_newHeads  use res record result, res length is subscribed count, use Response.Time record  subscribe return time
func Websocket_eth_subscribe_newHeads(cfg *utils.Config, method string, timeOut time.Time) ([]*utils.Response, error) {
	r := &utils.Response{Name: method, Code: 200}
	var res []*utils.Response
	ws := cfg.WsHost[rand.Intn(len(cfg.WsHost))]
	webClient, _, err := websocket.DefaultDialer.Dial(ws, nil)
	if err != nil {
		logutil.Errorf("dial err: %v", err)
		r.Code = -1
		res = append(res, r)
		return res, err
	}
	defer webClient.Close()
	msg, err := utils.NewMsg("eth_subscribe", "newHeads")
	if err != nil {
		logutil.Error("NewMsg:", err)
		r.Code = -1
		res = append(res, r)
		return res, err
	}
	return subscribe(webClient, msg, res, method, 7, timeOut)

}

// Websocket_eth_subscribe_logs  use res record result, res length is subscribed count, use Response.Time record  subscribe return time
func Websocket_eth_subscribe_logs(cfg *utils.Config, method string, address []common.Address, topic0, topic1, topic2, topic3 []common.Hash, timeOut time.Time) ([]*utils.Response, error) {
	r := &utils.Response{Name: method, Code: 200}
	var res []*utils.Response
	webClient, _, err := websocket.DefaultDialer.Dial(cfg.WsHost[rand.Intn(len(cfg.WsHost))], nil)
	if err != nil {
		r.Code = -1
		res = append(res, r)
		return res, err
	}
	filterQuery := ethereum.FilterQuery{
		Addresses: address,
		Topics:    [][]common.Hash{topic0, topic1, topic2, topic3},
	}
	params, err := utils.ToFilterParams(filterQuery)
	if err != nil {
		logutil.Error("ToFilterParams:", err)
		r.Code = -1
		res = append(res, r)
		return res, err
	}
	defer webClient.Close()
	msg, err := utils.NewMsg("eth_subscribe", "logs", params)
	if err != nil {
		logutil.Error("NewMsg:", err)
		r.Code = -1
		res = append(res, r)
		return res, err
	}
	return subscribe(webClient, msg, res, method, 7, timeOut)
}

// Websocket_eth_subscribe_newPendingTransactions  use res record result, res length is subscribe return count, use Response.Time record subscribe return time
func Websocket_eth_subscribe_newPendingTransactions(cfg *utils.Config, method string, timeOut time.Time) ([]*utils.Response, error) {
	r := &utils.Response{Name: method, Code: 200}
	var res []*utils.Response
	webClient, _, err := websocket.DefaultDialer.Dial(cfg.WsHost[rand.Intn(len(cfg.WsHost))], nil)
	if err != nil {
		logutil.Errorf("dial: %v", err)
		r.Code = -1
		res = append(res, r)
		return res, err
	}
	defer webClient.Close()
	msg, err := utils.NewMsg("eth_subscribe", "newPendingTransactions")
	if err != nil {
		logutil.Error("NewMsg:", err)
		r.Code = -1
		res = append(res, r)
		return res, err
	}
	return subscribe(webClient, msg, res, method, 30, timeOut)
}

func subscribe(webClient *websocket.Conn, msg *utils.JsonRpcMessage, res []*utils.Response, method string, readDeadline int, timeOut time.Time) ([]*utils.Response, error) {
	r := &utils.Response{Name: method, Code: 200}
	err := webClient.WriteJSON(msg)
	if err != nil {
		logutil.Errorf("WriteJSON err: %v", err)
		r.Code = -1
		res = append(res, r)
		return res, err
	}
	interval := time.Duration(readDeadline) * time.Second
	err = webClient.SetReadDeadline(time.Now().Add(interval))
	if err != nil {
		logutil.Errorf("SetReadDeadline err: %v", err)
		r.Code = -1
		res = append(res, r)
		return res, err
	}
	preTime := time.Now()
	for {
		_, message, err := webClient.ReadMessage()
		if err != nil {
			logutil.Errorf("read msg err:%v", err)
			r.Code = -1
			res = append(res, r)
			return res, err
		}
		err = webClient.SetReadDeadline(time.Now().Add(interval))
		if err != nil {
			logutil.Errorf("SetReadDeadline err: %v", err)
			r.Code = -1
			res = append(res, r)
			return res, err
		}
		logutil.Tracef("Received: %s.\n", message)
		// record time
		currTime := time.Now()
		duration := currTime.Sub(preTime).Milliseconds()
		preTime = currTime
		r.Time = duration
		res = append(res, r)
		if time.Now().Sub(timeOut) >= 0 {
			logutil.Debugf("===%s Subscription time reached ===", method)
			return res, nil
		}
		logutil.Debugf("===subscribe %s count: %d===", method, len(res))
	}
}
