package main

import (
	"bufio"
	"flag"
	"fmt"
	"math"
	"math/rand"
	"os"
	"sort"
	"sync"
	"time"

	"rpc-load-test/test"
	"rpc-load-test/utils"
	"rpc-load-test/utils/logutil"

	"github.com/aws/aws-lambda-go/lambda"

	"github.com/panjf2000/ants/v2"

	"go.uber.org/ratelimit"
)

var (
	testnode       *string
	fullnode       *string
	wsUrl          *string
	qps            *int
	dur            *int
	lLevel         *int
	apiKey         *string
	goroutineLimit *int
)

func init() {
	testnode = flag.String("testnode", "", "testnode")
	fullnode = flag.String("fullnode", "", "fullnode")
	wsUrl = flag.String("wsUrl", "", "websocket url ")
	qps = flag.Int("qps", 3, "qps")
	dur = flag.Int("dur", 0, "dur")
	lLevel = flag.Int("lLevel", 0, "lLevel")
	goroutineLimit = flag.Int("goroutineLimit", 0, "goroutineLimit")
	apiKey = flag.String("apiKey", "", "meganode apiKey, use ',' slice")
	flag.Parse()
}

func main() {
	//
	err := utils.T_cfg.LoadYML(*testnode, *fullnode, *wsUrl, *apiKey, *qps, *dur, *lLevel, *goroutineLimit)
	if err != nil {
		panic(err)
	}
	//
	if utils.T_cfg.IsStandalone {
		HandleRequest()
		return
	}
	//
	lambda.Start(HandleRequest)
}

func HandleRequest() (string, error) {
	//
	rand.Seed(time.Now().UnixNano())
	//
	exec(utils.T_cfg)
	//
	return "Completed", nil
}

func setupTimer(dur time.Duration) *bool {
	t := time.NewTimer(dur)
	expired := false
	go func() {
		<-t.C
		expired = true
	}()
	return &expired
}

func exec(cfg *utils.Config) {
	//
	rlimiter := ratelimit.New(cfg.ScenariosPerSec)
	//
	resCurr := make(map[string][]int64)
	fCurr := make(map[string]int64)
	resAggr := make(map[string][]Result)
	//
	dSec := time.Duration(cfg.DurationSec) * time.Second
	expired := setupTimer(dSec)
	time.Sleep(1 * time.Second)
	//
	var wg sync.WaitGroup
	var m sync.Mutex
	// query fullnode height
	if cfg.FullClient != nil {
		go func() {
			for {
				time.Sleep(3 * time.Second)
				//
				if *expired {
					break
				}
				//
				height, err := utils.GetHeight(cfg.FullClient)
				if err != nil {
					logutil.Error("GetHeight: " + err.Error())
					continue
				}
				//
				m.Lock()
				cfg.Height = height
				m.Unlock()
				//
				logutil.Infof("height: %d", cfg.Height)
			}
		}()
	}
	// collect batch results
	var writer *bufio.Writer
	if cfg.IsStandalone {
		//
		timestamp := time.Now().UnixNano()
		fpath := fmt.Sprintf("./results/%d_%d.csv", cfg.ScenariosPerSec, timestamp)
		resfile, err := os.OpenFile(fpath, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0644)
		if err != nil {
			panic(err)
		}
		defer resfile.Close()
		writer = bufio.NewWriter(resfile)
		//
		go func() {
			for {
				time.Sleep(time.Duration(cfg.AggrInterval) * time.Second)
				//
				if *expired {
					break
				}
				//
				m.Lock()
				successes := resCurr
				resCurr = map[string][]int64{}
				failures := fCurr
				fCurr = map[string]int64{}
				m.Unlock()
				//
				collectResults(successes, failures, resAggr, writer)
			}
		}()
	}

	if cfg.GoroutineLimit == 0 {
		cfg.GoroutineLimit = math.MaxInt
	}
	pool, _ := ants.NewPool(cfg.GoroutineLimit)
	defer pool.Release()
	for {
		if *expired {
			break
		}

		rlimiter.Take()
		wg.Add(1)
		pool.Submit(func() {
			defer wg.Done()
			//
			res := test.Run(cfg)
			//
			m.Lock()
			for _, v := range res {
				if v.Code != -1 {
					resCurr[v.Name] = append(resCurr[v.Name], v.Time)
				} else {
					fCurr[v.Name]++
				}
			}
			m.Unlock()
		})
	}
	wg.Wait()
	//
	m.Lock()
	successes := resCurr
	resCurr = map[string][]int64{}
	failures := fCurr
	fCurr = map[string]int64{}
	m.Unlock()
	//
	collectResults(successes, failures, resAggr, writer)
	//
	if !cfg.IsStandalone {
		logutil.Info("Final:", resAggr)
		return
	}
	//
	for method, res := range resAggr {
		points := utils.NewPoints()
		for _, v := range res {
			points.AVG = append(points.AVG, float64(v.RtAVG))
			points.P50 = append(points.P50, float64(v.RtP50))
			points.P90 = append(points.P90, float64(v.RtP90))
		}
		points.RenderChart("./results",
			fmt.Sprintf("%s.png", method))
	}
}

type Result struct {
	Success int64
	Failure int64
	RtAVG   int64
	RtP50   int64
	RtP90   int64
}

func collectResults(successes map[string][]int64, failures map[string]int64, resAggr map[string][]Result, writer *bufio.Writer) {
	//
	for method, numbers := range successes {
		sort.Slice(numbers, func(i int, j int) bool {
			return numbers[i]-numbers[j] < 0
		})
		//
		var rtSum int64 = 0
		total := int64(len(numbers))
		//
		for _, v := range numbers {
			rtSum += v
		}
		var avg int64 = 0
		if total != 0 {
			avg = rtSum / total
		}
		l50 := numbers[int64(float64(total)*0.5)]
		l90 := numbers[int64(float64(total)*0.9)]
		//

		if writer != nil {
			line := fmt.Sprintf("%s,%d,%d,%d,%d,%d\n",
				method, total, failures[method], avg, l50, l90)
			writer.WriteString(line)
			writer.Flush()
		}
		logutil.Infof("method: %s ; total: %d ; error: %d, (ms) avg: %d ; 50%%: %d ; 90%%: %d",
			method, total, failures[method], avg, l50, l90)
		result := Result{total, failures[method], avg, l50, l90}
		resAggr[method] = append(resAggr[method], result)
	}
	logutil.Info("----print result----")
}
