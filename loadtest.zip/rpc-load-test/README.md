this tool supports running as standalone program as well as aws lambda

lambda:

env GOOS=linux go build -ldflags="-s -w" -o build/loadtest loadtest.go

env GOOS=linux go build -ldflags="-s -w" -o build/controller controller.go

sls deploy --force --region us-east-1

sls remove --region us-east-1
